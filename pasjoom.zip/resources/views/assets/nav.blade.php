<div class="gradient"></div>
<nav class="pasjoom-nav">
	<div class="logo">
		<img src="img/logo.png" width="200px">
	</div>

	<div class="nav-right">
		<a href="#"><div class="nav-el">About</div></a>
		<a href="#"><div class="nav-el">Contact</div></a>
		<a href="#"><div class="nav-el">Sign in/Join</div></a>
		<a href="#"><div class="nav-el nav-mag"><i class="fas fa-search"></i></div></a>
	</div>
</nav>