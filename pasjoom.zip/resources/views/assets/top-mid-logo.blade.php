<div class="top-mid-logo-div">
	<center>
		<div>
			<div class="inline"><img src="img/logo.jpg" class="img-logo"></div>
			<div class="top-mid-title">P A S J O O M ·</div>
		</div>
	</center>
</div>