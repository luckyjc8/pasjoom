<div class="footer">
	<div class="foot-links inline">
		<ul class="footer-ul">
			<li>ABOUT</li>
			<li>HELP</li>
			<li>TERMS</li>
		</ul>
	</div>

	<div class="copyright inline">
		©2018 Pasjoom All Right Reserved. Privacy Policy/ Terms & Condition
	</div>
</div>