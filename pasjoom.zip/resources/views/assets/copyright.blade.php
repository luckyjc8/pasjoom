<div class="copyright">
	© 2009 PASJOOM
</div>