@extends('template/template1')

@section('title','Home')

@section('content')

<h1>This is content</h1>

@endsection