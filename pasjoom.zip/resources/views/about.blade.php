@extends('template.template2')

@section('title','Login')

@section('content')
    <div style="height:300px;margin-top:50px">
    <img src="img/logo2.jpg" class="about-img"/>
    <div class="about-div inline">
        THE STORY<br><br>
        when someone's past can become someone else's <br><br>
        Present and Future
    </div>
    </div>
@endsection