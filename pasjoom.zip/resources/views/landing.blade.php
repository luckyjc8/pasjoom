@extends("template/template")

@section('title','PASJOOM - Landing')


@section('body')
	<img class="landing-img" src="img/landing-image.png"/>
	<div class="landing-caption">
		<img src="img/icon.png" width="50px"/><br>
		A resale marketplace for<br>
		curated men's goods
	</div>
	<a href="#">
		<div class="landing-digging">
			Start Digging
		</div>
	</a>
	@include('assets/copyright')
@endsection