<?php $__env->startSection('title','Login'); ?>

<?php $__env->startSection('content'); ?>
    <div style="height:300px;margin-top:50px">
    <img src="img/logo2.jpg" class="about-img"/>
    <div class="about-div inline">
        THE STORY<br><br>
        when someone's past can become someone else's <br><br>
        Present and Future
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.template2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>