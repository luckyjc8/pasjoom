int avisennaganteng(){
	return 0;
}